import { Personagem } from "./Personagem"

let jaspion : Personagem = new Personagem ("Jaspion")

let giraia : Personagem = new Personagem ("Giraia")

let golias :Personagem = new Personagem ("Golias")

let davi :Personagem = new Personagem ("Davi")


// console.log(jaspion.vida )

// jaspion.machucar(998,giraia)
// console.log(giraia.vida)

// davi.machucar(500, davi)
// console.log(davi.vida)
// O personagem não pode causar dano nele mesmo!

// jaspion.machucar(800, giraia)
// console.log(giraia.vida)

// davi.curar(100, giraia)
// console.log(giraia.vida)

// Personagem.level(10, jaspion)

jaspion.subirNivel(9)
console.log(jaspion.level)



