import { Personagem } from "./Personagem";

export class guilda {
    membros: Set<Personagem>

    constructor(){
        this.membros = new Set<Personagem> ();
    }

adicionarMembro (membro:Personagem){
    this.membros.add(membro);
}
removerMembro (membro:Personagem){
    this.membros.delete(membro);
}

aliado(personagem:Personagem){
    return this.membros.has(personagem);
}
}