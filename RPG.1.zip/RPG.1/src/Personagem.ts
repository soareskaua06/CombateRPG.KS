export class Personagem {
      nome: string
      vida: number
      level: number = 1
      vivo: boolean = true


      constructor (nome : string){
    this.nome = nome
    this.level = 1
    this.vida = 1000
    this.vivo = true
 }


getNome (){
  return this.nome
}

subirNivel(level : number){
       if(this.nome){
       this.level = level + 1
       return true
       }

}

machucar(dano:number, alvo:Personagem){
  if (this.nome == alvo.getNome()){
      console.log("Você não pode causar dano em ti mesmo!")

  }else if(this.vivo){

    let nivelDiferenca = alvo.level - this.level
    let nivelDano = nivelDiferenca >= 5 ? 0.5 : nivelDiferenca
    let danoCausado = dano * nivelDano
    alvo.vida = Math.max(alvo.vida - danoCausado, 0)  

      if(alvo.vivo == true){
          alvo.vida = alvo.vida - dano
          if(alvo.vida > 0){
              alvo.vivo = true
          }else{
           alvo.vivo = false
          } 
        }
      }
    }

curar(cura:number, alvo:Personagem){
  if(alvo.getNome() == this.getNome()){
console.log("Você apenas pode curar a vc mesmo!")
  }
  if(alvo.vivo == true){
        

              
              
              if(alvo.vida >0 && alvo.vida <= 1000 ){
                alvo.vida = alvo.vida + cura
                alvo.vivo = true

                if(alvo.vida >1000){
                  alvo.vida = 1000
                  
  
                }
              }else{
                  alvo.vivo = false
                  alvo.vida = 0
  
                 
              }
  
          
          } else{
  
              console.log("\n")
              console.log("Personagem morto, não pode ser curado", alvo.nome)
      }
    
  }
  



      }